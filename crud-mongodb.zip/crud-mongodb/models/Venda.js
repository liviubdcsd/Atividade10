const mongoose = require("mongoose");

const vendaSchema = new mongoose.Schema({
  mes: { type: String, required: true },
  valor: { type: Number, required: true }
}, { timestamps: true });

module.exports = mongoose.model("Venda", vendaSchema);
