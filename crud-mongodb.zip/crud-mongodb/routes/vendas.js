const express = require("express");
const router = express.Router();
const Venda = require("../models/Venda");

router.post("/", async (req, res) => {
  try {
    const novaVenda = await Venda.create(req.body);
    res.status(201).json(novaVenda);
  } catch (err) {
    res.status(400).json({ erro: err.message });
  }
});

router.get("/", async (req, res) => {
  const vendas = await Venda.find();
  res.json(vendas);
});

router.get("/:id", async (req, res) => {
  const venda = await Venda.findById(req.params.id);
  if (venda) res.json(venda);
  else res.status(404).json({ erro: "Venda não encontrada" });
});

router.put("/:id", async (req, res) => {
  try {
    const atualizada = await Venda.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(atualizada);
  } catch (err) {
    res.status(400).json({ erro: err.message });
  }
});

router.delete("/:id", async (req, res) => {
  await Venda.findByIdAndDelete(req.params.id);
  res.json({ msg: "Venda deletada" });
});

module.exports = router;
